clc
clear all

filename ={[pwd '\data\k-files\k1.txt']}

% struct (or object) which is used down the blocks for further processing
for i = 1
nnn=dateFormatRewrite(filenames{i});
end
