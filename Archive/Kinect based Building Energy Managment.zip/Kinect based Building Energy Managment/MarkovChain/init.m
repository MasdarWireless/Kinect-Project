% init
addpath(genpath(fileparts(mfilename('fullpath'))));